Getting Started
===============

This page details how to get started with fireball. 
