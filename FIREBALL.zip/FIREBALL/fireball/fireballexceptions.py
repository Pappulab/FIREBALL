class FireballException(Exception):
    pass
