API Documentation
=================

.. autosummary::
   :toctree: autosummary

   fireball.canvas
